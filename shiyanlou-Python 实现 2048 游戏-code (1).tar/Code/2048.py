import curses
#在终端上显示图形界面
from random import randrange, choice
#生成随机数
from collections import defaultdict
#提供字典的子类     key值不存在时value的默认值

actions = ['Up', 'Left', 'Down', 'Right', 'Restart', 'Exit']
#游戏行为
letter_codes = [ord(ch) for ch in 'WASDRQwasdrq']
#ord()函数，以一个字符为参数，返回参数所对应的ASCII数值，便于捕捉键位
actions_dict = dict(zip(letter_codes, actions * 2))
#关联键位与行为

def main(stdscr):
    
	def init():
	#初始化棋盘
	return 'Game'

	def not_game(state):
	'''画出GameOver或Win界面
	读取用户输入得到action，判断重启或结束游戏
	'''
	responses = defaultdict(lambda:state)#默认是当前状态，没有Restart和Exit行为会保持当前状态
	responses['Restart'],responses['Exit'] = 'Init', 'Exit'#将行为和状态对应
	return responses[action]
	
	def game():
    #画出当前棋盘状态，
    	if action == 'Restart':
			return 'Init'
    	if action == 'Exit':
			return 'Exit'
	#读取用户输入action
	#if成功移动一步
			if 游戏胜利:
	    		return 'Win'
			if 游戏失败:
	    		return 'Over'
    	return 'Game'

	state_actions = {
		'Init':init,
		'Win': lambda: not_
	
